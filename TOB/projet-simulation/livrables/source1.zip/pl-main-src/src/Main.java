import simulation2D.Launch;

/**
 * La classe <code>Main</code> est la classe principale du projet. Elle ne fait
 * pas partie du package simulation2D.
 *
 * @author Vianney Hervy
 */
public class Main {

    /**
     * Lancer l'application.
     */
    public static void main(String[] args) {
        Launch.launch();
    }
}
