package simulation2D.simulation;

import javax.swing.SwingUtilities;
import javax.swing.JPanel;

import simulation2D.Launch;
import simulation2D.physics.Collision;
import simulation2D.physics.Force;
import simulation2D.physics.MoteurPhysique;
import simulation2D.objects.Dico2D;

// Une classe qui gère la boucle de simulation, y compris le temps, les mises à
// jour de l'état de la simulation et le rendu graphique.

/**
 * La classe <code>SimulationLoop</code> gère la boucle de simulation, y compris
 * le temps, les mises à jour de l'état de la simulation et le rendu graphique.
 * 
 * @author Vianney Hervy
 */
public class SimulationLoop implements Runnable {

    /**
     * L'état de la boucle de simulation (true si la boucle est en cours, false
     * sinon).
     */
    private boolean running = false;

    /**
     * L'état de la simulation.
     */
    private SimulationState simulationState;

    /**
     * Le panneau de dessin de la simulation.
     */
    private JPanel panel;

    /**
     * Construire une boucle de simulation étant donné un état de simulation et un panneau de dessin.
     *
     * @param simulationState l'état de la simulation
     * @param panel le panneau de dessin
     */
    public SimulationLoop(SimulationState simulationState, JPanel panel) {
        this.simulationState = simulationState;
        this.panel = panel;
    }

    /**
     * Démarrer la boucle de simulation.
     */
    public void start() {
        running = true;
        new Thread(this).start();
    }

    /**
     * Arrêter la boucle de simulation.
     */
    public void stop() {
        running = false;
    }

    /**
     * Exécuter la boucle de simulation.
     */
    @Override
    public void run() {
        while (running) {
            // mise à jour de l'état de la simulation
            Force.calculateForces(simulationState.getObjects(), simulationState.getRelations());
            MoteurPhysique.applyForces(simulationState.getObjects());
            Collision.checkWallCollisions(simulationState.getObjects());
            Collision.checkObjectCollisions(simulationState.getObjects());
            MoteurPhysique.updatePositions(simulationState.getObjects());

            // demander une mise à jour du rendu
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    panel.repaint();
                }
            });

            // Pause pour limiter la vitesse de la boucle
            try {
                Thread.sleep(1000 / Launch.FPS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

}
