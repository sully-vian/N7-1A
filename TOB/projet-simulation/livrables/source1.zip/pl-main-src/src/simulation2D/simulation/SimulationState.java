package simulation2D.simulation;

import java.util.ArrayList;
import java.util.Random;
import java.util.List;
import java.awt.Color;

import simulation2D.Launch;
import simulation2D.objects.Particule;
import simulation2D.objects.Famille;
import simulation2D.physics.Vecteur2D;
import simulation2D.physics.Relation;
import simulation2D.menu.MenuTextuel;
import simulation2D.objects.Dico2D;

/**
 * La classe <code>SimulationState</code> gère l'état de la simulation, y
 * compris tous les objets actuellement dans la simulation.
 *
 * @author Vianney Hervy
 */
public class SimulationState {

    /**
     * La liste des objets actuellement dans la simulation.
     */
    private List<Particule> objects;

    private Dico2D relations;

    private List<Famille> familles;

    /**
     * Construire un état de simulation avec 500 objets de caractéristiques
     * aléatoires et un objet central plus gros, plus lourd pour tester les lois de
     * collision.
     */
    public SimulationState() {
        this.objects = new ArrayList<>();

        Color[] colors = {
                Color.BLACK, Color.BLUE, Color.CYAN, Color.DARK_GRAY, Color.GRAY,
                Color.GREEN, Color.MAGENTA, Color.ORANGE, Color.PINK,
                Color.RED, Color.YELLOW, Color.WHITE
        };

        Random rand = new Random();

        /*Particule object;
        for (int i = 0; i < 500; i++) {
            object = Particule.builder()
                    .position(new Vecteur2D(rand.nextInt(Launch.WIDTH), rand.nextInt(Launch.HEIGHT)))
                    .mass(10)
                    .radius(5)
                    .velocity(new Vecteur2D(rand.nextInt(100) - 50, rand.nextInt(100) - 50).times(2))
                    .color(colors[rand.nextInt(colors.length)])
                    .build();
            objects.add(object);
        }

        object = Particule.builder()
                .position(new Vecteur2D(Launch.WIDTH / 2, Launch.HEIGHT / 2))
                .mass(100)
                .radius(25)
                .velocity(new Vecteur2D(0, 0))
                .color(Color.RED)
                .build();

        objects.add(object);*/


        final MenuTextuel menu = new MenuTextuel();
        menu.execMenu();

        this.objects = menu.getParticules();
        this.relations = menu.getRelations();
        this.familles = menu.getFamilles();





    }

    /**
     * Obtenir la liste des objets actuellement dans la simulation.
     * @return la liste des objets actuellement dans la simulation
     */
    public List<Particule> getObjects() {
        return objects;
    }

    public Dico2D getRelations() {
      return relations;
    }

    public List<Famille> getFamilles() {
      return familles;
    }
}