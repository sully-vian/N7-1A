package simulation2D.rendering;

import java.util.List;
import java.awt.Graphics2D;

import simulation2D.objects.Particule;
import simulation2D.simulation.SimulationState;


/**
 * La classe <code>Renderer</code> est responsable de l'affichage des objets.
 *
 * @author Vianney Hervy
 */
public class Affichage {
    private SimulationState simulationState;

    /**
     * Construire un nouveau <code>Renderer</code> avec l'état de la simulation.
     * @param simulationState l'état de la simulation
     */
    public Affichage(SimulationState simulationState) {
        this.simulationState = simulationState;
    }

    /**
     * Afficher les objets de la simulation.
     * @param g le contexte graphique
     */
    public void render(Graphics2D g) {
        List<Particule> objects = simulationState.getObjects();
        for (Particule objet : objects) {
            objet.draw(g);
        }
    }
}