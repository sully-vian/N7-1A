package simulation2D.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.awt.Color;

import simulation2D.objects.Particule;
import simulation2D.physics.Vecteur2D;
import simulation2D.physics.Relation;
import simulation2D.Launch;
import simulation2D.objects.Famille;
import simulation2D.objects.Dico2D;

/**
 * Gère le menu textuel de la première itération (sera remplacé par un menu graphique plus tard)
 * 
 * @author Baptiste Gomez
 */
public class MenuTextuel {

  private List<Particule> objects;

  private List<Famille> familles;

  private Dico2D relations;

  public MenuTextuel() {
    this.objects = new ArrayList<>();
    this.familles = new ArrayList<>();
    this.relations = new Dico2D(0);
  }

  public List<Particule> getParticules() {
    return this.objects;
  }

  public List<Famille> getFamilles() {
    return this.familles;
  }

  public Dico2D getRelations() {
    return this.relations;
  }
  
  public void execMenu() {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Combien de familles voulez-vous ? ");
    int nbFamilles = scanner.nextInt();
    System.out.print("Combien de particules par famille voulez-vous ? ");
    int nbParticules = scanner.nextInt();
    scanner.close();

    genererSimulation(nbParticules, nbFamilles);

    genererRelations();
  }

  private void genererSimulation(int nbParticules, int nbFamilles) {
    Famille famille;
    for (int i = 0; i < nbFamilles; i++) {
      famille = genererFamille();
      this.familles.add(famille);
      Particule particule;
      for (int j = 0; j < nbParticules; j++) {
        particule = genererParticule(famille);
        this.objects.add(particule);
      }
    }
  }

  private Particule genererParticule(Famille famille) {
    Random rand = new Random();
    Particule res = new Particule(famille, new Vecteur2D(rand.nextInt(Launch.WIDTH), rand.nextInt(Launch.HEIGHT)), new Vecteur2D(rand.nextInt(100) - 50, rand.nextInt(100) - 50).times(2));
    return res;
  }

  private Famille genererFamille() {
    Random rand = new Random();
    Color[] colors = {
      Color.BLACK, Color.BLUE, Color.CYAN, Color.DARK_GRAY, Color.GRAY,
      Color.GREEN, Color.MAGENTA, Color.ORANGE, Color.PINK,
      Color.RED, Color.YELLOW, Color.WHITE
    };
    Famille res = new Famille("", colors[rand.nextInt(colors.length)], rand.nextInt(100), rand.nextInt(50), 0);
    return res;
  }

  private void genererRelations() {
    Random rand = new Random();
    for (Famille famille_attractice : this.familles) {
      for (Famille famille_subis : this.familles) {
        this.relations.Modifier_Relation(famille_attractice, famille_subis, rand.nextInt(100));
      }
    }
  }

}
