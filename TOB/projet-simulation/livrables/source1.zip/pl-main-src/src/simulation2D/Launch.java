package simulation2D;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Dimension;

import simulation2D.rendering.Affichage;
import simulation2D.simulation.SimulationLoop;
import simulation2D.simulation.SimulationState;

/**
 * La classe <code>Launch</code> est le point d'entrée de l'application. Elle
 * initialise l'application et lance la boucle de simulation.
 *
 * @author Vianney Hervy
 */
public class Launch {

    /**
     * Le nombre d'images par seconde de la simulation. Cette valeur concerne
     * l'affichage tout comme le calcul des positions par le moteur physique.
     */
    public static final int FPS = 60;

    /**
     * La largeur de la fenêtre de l'application et de l'espace de simulation.
     */
    public static final int WIDTH = 800;

    /**
     * La hauteur de la fenêtre de l'application et de l'espace de simulation.
     */
    public static final int HEIGHT = 600;

    /**
     * Lancer la simulation.
     */
    public static void launch() {
        // Créer l'étatde la simulation
        SimulationState simulationState = new SimulationState();

        // Créer moteur de rendu
        final Affichage renderer = new Affichage(simulationState);

        // Créer la fenêtre de l'application
        JFrame frame = new JFrame("Simulation 2D");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(WIDTH, HEIGHT);
        frame.setVisible(true);

        // ajouter un panneau de dessin à la fenêtre
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                renderer.render((Graphics2D) g);
            }
        };
        panel.setBackground(Color.LIGHT_GRAY);
        panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        frame.add(panel);
        frame.pack();

        // Créer la boucle de simulation
        SimulationLoop simulationLoop = new SimulationLoop(simulationState, panel);

        // Lancer la boucle de smulation
        simulationLoop.start();
    }
}