package simulation2D.physics;
/** 
 * Classe de test de la classe Vecteur2D.
 *
 * @author Yassine Bougacha
 */

//  package simulation2D.physics;

import static org.junit.Assert.*;

import org.junit.*;

public class Vecteur2DTest {

		// Précision pour les comparaisons réelle:
		public final static double EPSILON = 0.001;

		// Les vecteurs du sujet
		private Vecteur2D V1, V2, V3, V4, V5, V6;

		@Before public void setUp() {
			// Construire des vecteurs 2D:
			V1 = new Vecteur2D(5,2 );
			V2 = new Vecteur2D(2.4,2.12 );
			V3 = new Vecteur2D(-3,-12 );
			V4 = new Vecteur2D(-2,0 );
			V5 = new Vecteur2D(7,2 );
			V6 = new Vecteur2D(1, 1); 
		} 		

		/**
		 * Vérifier si deux vecteurs ont memes coordonnées
	 	* @param Vect1 le premier vecteur
	 	* @param Vect2 le deuxiéme vecteur    
	 	*/
		static void memesCoordonnees(String message, Vecteur2D Vect1, Vecteur2D Vect2) {
			assertEquals(message + "(x)", Vect1.getX(), Vect2.getX(),EPSILON);
			assertEquals(message + "(y)", Vect1.getY(), Vect2.getY(),EPSILON);
		} 

		@Test
		public void testGetXGetY() {
			// Test getX():
			assertEquals("coordonnée x incorrecte", V1.getX(),5,EPSILON);
			assertEquals("coordonnée x incorrecte", V3.getX(),-3,EPSILON);
			// Tests getY)():
			assertEquals("coordonnée x incorrecte", V1.getY(),2,EPSILON);
			assertEquals("coordonnée x incorrecte", V3.getY(),-12,EPSILON);
		}

		@Test
		public void testSetXSetY() {
			V2.setX(5);
			V2.setY(2);
			memesCoordonnees("SetX|SetY incorrecte ", V1, V2);
		}

		@Test
		public void testNorm2() {
			assertEquals("Norm2 incorrecte", V4.norm2(),4,EPSILON);
			assertEquals("Norm2 incorrecte", V1.norm2(),29,EPSILON);
		}

		@Test
		public void testAddPlusMinus() {
			// Test add:
			Vecteur2D V_test1 = new Vecteur2D(3, 2 );
			V1.add(V4);
			memesCoordonnees("add incorecte", V1, V_test1);
			// Test plus:
			Vecteur2D V_test2 = V2.plus(V3);
			Vecteur2D V_test22 = new Vecteur2D(-0.6, -9.88);
			memesCoordonnees("plus incorecte", V_test2, V_test22);
			// Test minus
			Vecteur2D V_test3 = V5.minus(V6);
			Vecteur2D V_test33 = new Vecteur2D(6, 1);
			memesCoordonnees("minus incorecte", V_test3, V_test33);
		}

		@Test
		public void testMultiplication() {
			// Test times:
			Vecteur2D V_test11 = V3.times(-1);
			Vecteur2D V_test1 = new Vecteur2D( 3,  12);
			memesCoordonnees("times incorrecte", V_test11, V_test1);
			// Test devide:
			Vecteur2D V_test22 = V4.divide(2);
			Vecteur2D V_test2 = new Vecteur2D(-1, 0);
			memesCoordonnees("devide incorrecte", V_test2, V_test22);
			// Test dotProduct
			double produit = V1.dotProduct(V2);
			assertEquals("dotProduct incorrecte", produit, 16.24,EPSILON);
		}

		@Test
		public void testNormalized() {
			V6 = V6.normalized();
			double norm = Math.sqrt(2);
			Vecteur2D V_test1 = new Vecteur2D(1/norm, 1/norm);
			memesCoordonnees("normalized incorrecte", V_test1, V6);

		}

		@Test
		public void testNormalize() {
			V6.normalize();
			double norm = Math.sqrt(2);
			Vecteur2D V_test1 = new Vecteur2D(1/norm, 1/norm);
			memesCoordonnees("normalizee incorrecte", V_test1, V6);
			
		}
	
		@Test
		public void testCopy() {
			Vecteur2D V_test1 = V1.copy();
			memesCoordonnees("copy incorrecte", V_test1, V1);
		}
}	

	
