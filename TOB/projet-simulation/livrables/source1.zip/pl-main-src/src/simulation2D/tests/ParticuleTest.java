package simulation2D.objects;
import simulation2D.Launch;
import simulation2D.physics.Vecteur2D;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ParticuleTest {

	// Précision pour les comparaisons réelle:
	public final static double EPSILON = 0.001;
	
	private Particule P1, P2, P3, P4;


	/**
	* Vérifier si deux vecteurs ont memes coordonnées
	* @param Vect1 le premier vecteur
	* @param Vect2 le deuxiéme vecteur    
	*/
	static void memesCoordonnees(String message, Vecteur2D Vect1, Vecteur2D Vect2) {
		assertEquals(message + "(x)", Vect1.getX(), Vect2.getX(),EPSILON);
		assertEquals(message + "(y)", Vect1.getY(), Vect2.getY(),EPSILON);
	} 

	/* 
	les paramètres d'une particule psont par default: 
    position : (Launch.WIDTH / 2, Launch.HEIGHT / 2)
    mass : 1
    radius : 10
    color : Color.BLACK
    velocity : (0, 0)
	*/

	@Before
	public void setUp() throws Exception {
		// Construction des particles 
		P1 = Particule.builder().build();
		P2 = Particule.builder().build();
		P3 = Particule.builder().build();
		P4 = Particule.builder().build();
	}

	@Test
	public void testPosition() {
		// Test getX
		assertEquals("getX incorrecte",P1.getX(),Launch.WIDTH/2,EPSILON);
		// Test getY
		assertEquals("getY incorrecte",P2.getY(),Launch.HEIGHT/2,EPSILON);
		// Test GetPosition
		Vecteur2D V_test1 = P1.getPosition();
		Vecteur2D V_test11 = new Vecteur2D(Launch.WIDTH/2, Launch.HEIGHT/2);
		memesCoordonnees("getPosition incorrecte", V_test1, V_test11);
		// Test setPosition (avec un vecteur en paramètre)
		Vecteur2D V_test2 = new Vecteur2D(3, 4);
		P2.setPosition(V_test2);
		memesCoordonnees("setPosition1 incorrecte", V_test2, P2.getPosition());
		// Test setPosition (avec des coordonnées en paramètre)
		Vecteur2D V_test3 = new Vecteur2D(-2, -4);
		P3.setPosition(-2,-4);
		memesCoordonnees("setPosition2 incorrecte", V_test3, P3.getPosition());
		// Test translate
		Vecteur2D V_test4 = new Vecteur2D(Launch.WIDTH/2 + 5, Launch.HEIGHT/2 - 6);
		Vecteur2D V_test44 = new Vecteur2D(5, - 6);
		P4.translate(V_test44);
		memesCoordonnees("translate incorrecte", V_test4, P4.getPosition());
	}

	@Test
	public void testGetMass_radius() {
		// Test getMass
		assertEquals("getMass incorrecte",1,P1.getMass(),EPSILON);
		// Test getRadius
		assertEquals("getRadius incorrecte", 10, P1.getRadius(),EPSILON);
	}	

	@Test
	public void testSetGetDirections() {
		// Test getLeft
		assertEquals("getLeft incorrecte", P1.getLeft(),
						P1.getX() - P1.getRadius(), EPSILON);
		// Test setLeft
		double leftX = 4;
		P1.setLeft(leftX);
		assertEquals("setLeft incorrecte", P1.getLeft(),
						leftX, EPSILON );
		
		// Test getRight
		assertEquals("getRight incorrecte", P2.getRight(),
						P2.getX() + P2.getRadius(),EPSILON);
		// Test setRight
		double rightX = - 3;
		P2.setRight(rightX);
		assertEquals("setLeft incorrecte", P2.getRight(),
					 rightX, EPSILON );
		
		// Test getTop
		assertEquals("getTop incorrecte", P3.getTop(),
					 P3.getY() - P3.getRadius(), EPSILON);
		// Test setTop
		double topY = 3;
		P3.setTop(topY);
		assertEquals("setTop incorrecte", P3.getTop(),
					 topY , EPSILON );
		
		// Test getBottom
		assertEquals("getBottom incorrecte", P4.getBottom(),
					 P4.getY() + P4.getRadius(), EPSILON);
		// Test setBottom
		double bottomY = 12.4;
		P4.setBottom(bottomY);
		assertEquals("setBottom incorrecte", P4.getBottom(),
					 bottomY, EPSILON);
	}

	@Test
	public void testVelocity() {
		// Test getVelocity
		Vecteur2D V_test1 = new Vecteur2D(0, 0);
		memesCoordonnees("getVelocity incorrecte", V_test1, P1.getVelocity());
		// Test setVelocity (avec un vecteur en paramètre)
		Vecteur2D V_test2 = new Vecteur2D(4, 3);
		P2.setVelocity(V_test2);
		memesCoordonnees("setVelocity1 incorrecte", V_test2, P2.getVelocity());
		// Test setVelocity (avec les coordonnées en paramètre)
		P3.setVelocity(4,3);
		memesCoordonnees("setVelocity2 incorrecte", V_test2, P3.getVelocity());
		// Test addVelocity
		P4.addVelocity(V_test2);
		memesCoordonnees("addVelocity", V_test2, P4.getVelocity());

	}

	@Test
	public void testForce() {
		// Test getForce
		Vecteur2D V_test1 = new Vecteur2D(0, 0);
		memesCoordonnees("getForce incorrecte", V_test1, P1.getForce());
		// Test setForce
		Vecteur2D V_test2 = new Vecteur2D(5, -2);
		P2.setForce(V_test2);
		memesCoordonnees("setForce incorrecte", V_test2, P2.getForce());
		// Test addForce
		P3.addForce(V_test2);
		memesCoordonnees("addForce incorrecte", V_test2, P3.getForce());
		// Test resetForce
		P3.resetForce();
		memesCoordonnees("resetForce incorrecte", V_test1, P3.getForce());
	}

	
	
}
