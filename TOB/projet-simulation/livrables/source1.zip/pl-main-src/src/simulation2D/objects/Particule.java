package simulation2D.objects;

import java.awt.Graphics2D;
import java.awt.Color;

import simulation2D.Launch;
import simulation2D.physics.Vecteur2D;

/**
 * La classe <code>SimulatedObject</code> représente un objet simulé dans un
 * espace 2D. Cet objet est caractérisé par sa position, sa masse, son rayon, sa
 * couleur et sa vitesse. Pour créer un tel objet, il est nécessaire d'utiliser
 * le {@link Builder} via la méthode {@link #builder()}.
 *
 * @author Vianney Hervy
 */
public class Particule {

    /**
     * La position de l'objet.
     */
    private Vecteur2D position;

    /**
     * La masse de l'objet.
     */
    private double mass;

    /**
     * Le rayon de l'objet.
     */
    private double radius;

    /**
     * La couleur de l'objet.
     */
    private Color color;

    /**
     * La vitesse de l'objet.
     */
    private Vecteur2D velocity;

    /**
     * Le vecteur force résultant de toutes les forces appliquées sur l'objet.
     */
    private Vecteur2D force;

    private Famille famille;

    public Particule(Famille famille, Vecteur2D position, Vecteur2D velocity) {
      this.position = position;
      this.velocity = velocity;
      this.mass = famille.getMass();
      this.radius = famille.getRadius();
      this.color = famille.getColor();
      this.famille = famille;
      this.force = new Vecteur2D(0, 0);
    }

    private Particule(Builder builder) {
        this.position = builder.position.copy();
        this.mass = builder.mass;
        this.radius = builder.radius;
        this.color = builder.color;

        this.velocity = builder.velocity.copy();
        this.force = new Vecteur2D(0, 0);
    }

    public Famille getFamille() {
      return this.famille.copy();
    }

    /**
     * Obtenir la position x de l'objet.
     *
     * @return la position x de l'objet
     */
    public double getX() {
        return this.position.getX();
    }

    /**
     * Obtenir la position y de l'objet.
     *
     * @return la position y de l'objet
     */
    public double getY() {
        return this.position.getY();
    }

    /**
     * Obtenir la position de l'objet sous forme de vecteur.
     *
     * @return le vecteur position de l'objet
     */
    public Vecteur2D getPosition() {
        return this.position.copy();
    }

    /**
     * Définir la position de l'objet par vecteur.
     *
     * @param v le nouveau vecteur position de l'objet
     */
    public void setPosition(Vecteur2D v) {
        this.position = v.copy();
    }

    /**
     * Définir la position de l'objet par coordonnées.
     *
     * @param x la coordonnée x de la nouvelle position
     * @param y la coordonnée y de la nouvelle position
     */
    public void setPosition(double x, double y) {
        this.setPosition(new Vecteur2D(x, y));
    }

    /**
     * Trabslater l'objet selon un vecteur.
     *
     * @param v le vecteur de translation
     */
    public void translate(Vecteur2D v) {
        this.position.add(v);
    }

    /**
     * Obtenir la masse de l'objet.
     *
     * @return la masse de l'objet
     */
    public double getMass() {
        return this.mass;
    }

    /**
     * Obtenir le rayon de l'objet.
     *
     * @return le rayon de l'objet
     */
    public double getRadius() {
        return this.radius;
    }

    /**
     * Définir la position du bord gauche de l'objet.
     *
     * @param leftX la nouvelle position du bord gauche de l'objet
     */
    public void setLeft(double leftX) {
        this.position.setX(leftX + radius);
    }

    /**
     * Obtenir la position du bord gauche de l'objet.
     *
     * @return la position du bord gauche de l'objet
     */
    public double getLeft() {
        return position.getX() - radius;
    }

    /**
     * Définir la position du bord droit de l'objet.
     *
     * @param rightX la nouvelle position du bord droit de l'objet
     */
    public void setRight(double rightX) {
        this.position.setX(rightX - radius);
    }

    /**
     * Obtenir la position du bord droit de l'objet.
     *
     * @return la position du bord droit de l'objet
     */
    public double getRight() {
        return position.getX() + radius;
    }

    /**
     * Définir la position du bord supérieur de l'objet.
     *
     * @param topY la nouvelle position du bord supérieur de l'objet
     */
    public void setTop(double topY) {
        this.position.setY(topY + radius);
    }

    /**
     * Obtenir la position du bord supérieur de l'objet.
     *
     * @return la position du bord supérieur de l'objet
     */
    public double getTop() {
        return position.getY() - radius;
    }

    /**
     * Définir la position du bord inférieur de l'objet.
     *
     * @param bottomY la nouvelle position du bord inférieur de l'objet
     */
    public void setBottom(double bottomY) {
        this.position.setY(bottomY - radius);
    }

    /**
     * Obtenir la position du bord inférieur de l'objet.
     *
     * @return la position du bord inférieur de l'objet
     */
    public double getBottom() {
        return position.getY() + radius;
    }

    /**
     * Obtenir le vecteur vitesse de l'objet.
     *
     * @return le vecteur vitesse de l'objet
     */
    public Vecteur2D getVelocity() {
        return this.velocity.copy();
    }

    /**
     * Définir la vitesse de l'objet par vecteur.
     *
     * @param v le nouveau vecteur vitesse de l'objet
     */
    public void setVelocity(Vecteur2D v) {
        this.velocity = v.copy();
    }

    /**
     * Définir la vitesse de l'objet par coordonnées.
     *
     * @param x la coordonnée x du nouveau vecteur vitesse
     * @param y la coordonnée y du nouveau vecteur vitesse
     */
    public void setVelocity(double x, double y) {
        setVelocity(new Vecteur2D(x, y));
    }

    /**
     * Ajouter une vitesse à la vitesse de l'objet.
     *
     * @param v le vecteur vitesse à ajouter à la vitesse de l'objet
     */
    public void addVelocity(Vecteur2D v) {
        this.velocity.add(v);
    }

    /**
     * Obtenir la résultante des forces agissant sur l'objet.
     *
     * @return la résultante des forces agissant sur l'objet
     */
    public Vecteur2D getForce() {
        return this.force.copy();
    }

    /**
     * Définir le vecteur résultante des forces agissant sur l'objet.
     *
     * @param v la nouvelle résultante des forces agissant sur l'objet
     */
    public void setForce(Vecteur2D v) {
        this.force = v.copy();
    }

    /**
     * Ajouter une force à laquelle l'objet est soumis
     *
     * @param v la nouvelle force auquel l'objet est soumis
     */
    public void addForce(Vecteur2D v) {
        this.force.add(v);
    }

    /**
     * Réinitialiser la résultante des forces agissant sur l'objet au vecteur
     * nul.
     */
    public void resetForce() {
        this.force = new Vecteur2D(0, 0);
    }

    /**
     * Dessiner l'objet.
     *
     * @param g le contexte graphique dans lequel dessiner l'objet
     */
    public void draw(Graphics2D g) {
        int topLeftX = (int) (this.getX() - this.radius);
        int topLeftY = (int) (this.getY() - this.radius);
        g.setColor(this.color);
        g.fillOval(topLeftX, topLeftY, (int) radius * 2, (int) radius * 2);
    }

    /**
     * Vérifier si l'objet chevauche un autre objet.
     *
     * @param other l'autre objet avec lequel vérifier le chevauchement
     * @return la distance entre les deux objets s'ils se chevauchent, -1 sinon
     */
    public double isOverlapping(Particule other) {
        double dx = this.getX() - other.getX();
        double dy = this.getY() - other.getY();
        double distance2 = dx * dx + dy * dy;
        boolean isOverlapping = distance2 < (this.radius + other.radius) * (this.radius + other.radius);
        return isOverlapping ? Math.sqrt(distance2) : -1;
    }

    /**
     * Créer un nouveau {@link Particule.Builder} pour construire un
     * objet.
     *
     * Exemple d'utilisation :
     *
     * <pre>
     * {@code
     * SimulatedObject = SimulatedObject.builder()
     *         .position(new Vector2D(1, 2))
     *         .mass(10)
     *         .radius(5)
     *         .velocity(new Vector2D(3, 4))
     *         .color(Color.RED)
     *         .build();
     * }
     * </pre>
     *
     * Aucun des paramètres n'est obligatoire, les valeurs par défaut sont :
     * <ul>
     * <li>position : (Launch.WIDTH / 2, Launch.HEIGHT / 2)</li>
     * <li>mass : 1</li>
     * <li>radius : 10</li>
     * <li>color : Color.BLACK</li>
     * <li>velocity : (0, 0)</li>
     * </ul>
     *
     * @return un nouveau {@link Particule.Builder} pour construire un
     *         objet
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * La classe <code>SimulatedObject.Builder</code> permet de construire un
     * {@link Particule} plus facilement. Elle fait usage du patron de
     * conception Builder.
     *
     * @author Vianney Hervy
     */
    public static class Builder {

        private Vecteur2D position = new Vecteur2D(Launch.WIDTH / 2, Launch.HEIGHT / 2);
        private double mass = 1;
        private double radius = 10;
        private Color color = Color.BLACK;
        private Vecteur2D velocity = new Vecteur2D(0, 0);

        private Builder() {
        }

        /**
         * Définir la position de l'objet en construction.
         *
         * @param position le vecteur position de l'objet
         * @return le {@link Particule.Builder} pour continuer la
         *         construction
         */
        public Builder position(Vecteur2D position) {
            this.position = position.copy();
            return this;
        }

        /**
         * Définir la masse de l'objet en construction. Par défaut, la masse est
         * de 1.
         *
         * @param mass la masse de l'objet
         * @return le {@link Particule.Builder} pour continuer la
         *         construction
         */
        public Builder mass(double mass) {
            this.mass = mass;
            return this;
        }

        /**
         * Définir le rayon de l'objet en construction. Par défaut, le rayon est
         * de 10.
         *
         * @param radius le rayon de l'objet
         * @return le {@link Particule.Builder} pour continuer la
         *         construction
         */
        public Builder radius(double radius) {
            this.radius = radius;
            return this;
        }

        /**
         * Définir la couleur de l'objet en construction. Par défaut, la couleur
         * est noire.
         *
         * @param color la couleur de l'objet
         * @return le {@link Particule.Builder} pour continuer la
         *         construction
         */
        public Builder color(Color color) {
            this.color = color;
            return this;
        }

        /**
         * Définir la vitesse initiale de l'objet en construction. Par défaut,
         * la vitesse est nulle.
         *
         * @param velocity la vitesse initiale de l'objet
         * @return le {@link Particule.Builder} pour continuer la
         *         construction
         */
        public Builder velocity(Vecteur2D velocity) {
            this.velocity = velocity.copy();
            return this;
        }

        /**
         * Construire l'objet définit par le {@link Particule.Builder}.
         *
         * @return l'objet construit
         */
        public Particule build() {
            return new Particule(this);
        }

    }
}
