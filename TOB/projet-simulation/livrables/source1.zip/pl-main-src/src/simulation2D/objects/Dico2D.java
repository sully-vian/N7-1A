package simulation2D.objects;

import java.util.HashMap;



/** La classe Dico2D permet de créer un dictionnaire dont les clés sont des familles
 *  et les valeurs sont des dictionnaires dont les clés sont des familles et les valeurs des double.
 *  Cette classe permet de manipuler facilement les relations entre les familles.
 * 
 * @author Thomas SABATIER
*/

public class Dico2D {


  private HashMap<Famille, HashMap<Famille, Double>> dico;


    public Dico2D(int nb_Famille){
        this.dico = new HashMap<Famille, HashMap<Famille, Double>>();
    }


    public void Modifier_Relation(Famille Fa, Famille Fb, double intensite){
        if (dico.containsKey(Fa)){
            dico.get(Fa).put(Fb, intensite);
        } else {
            HashMap<Famille, Double> Dico_Fa = new HashMap<Famille, Double>();
            Dico_Fa.put(Fb, intensite);
            dico.put(Fa, Dico_Fa);
        }
    }

    public void Supprimer_Relation(Famille Fa, Famille Fb){
        if (dico.containsKey(Fa)){
            dico.get(Fa).put(Fb, 0.0);
        }
    }

    public double getIntensite(Famille Fa, Famille Fb) {
      if (dico.containsKey(Fa)) {
        return this.dico.get(Fa).get(Fb);
      }
      return 0;
    }
  }