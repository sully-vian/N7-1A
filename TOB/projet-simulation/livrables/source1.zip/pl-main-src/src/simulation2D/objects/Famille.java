package simulation2D.objects;

import java.awt.Color;


/** La classe Famille permet de créer une famille de particules dont
 * l'utilisateur va choisir les différentes caractéristiques.
 * a completer
 * 
 * @author Leilie CANILLAC
*/

public class Famille {

    /**
     * Le nom de la famille.
     */
    public String nom;

    /**
     * La couleur de la famille.
     */
    private Color color;

    /**
     * La masse de la famille.
     */
    private double mass;

    /**
     * Le rayon de la famille.
     */
    private double radius;

    /**
     * Constructeur de l'objet Famille.
     */
    public Famille(String nom, Color color, double mass, double radius, int nbParticule) {
        this.nom = nom;
        this.color = color;
        this.mass = mass;
        this.radius = radius;
        
    }

    /**
     * Obtenir le nom de la famille.
     * 
     * @return le nom de la famille
     */
    public String getNom() {
        return this.nom;
    }

    /**
     * Obtenir la masse de la famille.
     *
     * @return la masse de la famille
     */
    public double getMass() {
        return this.mass;
    }

    /**
     * Obtenir le rayon de la famille.
     *
     * @return le rayon de la famille
     */
    public double getRadius() {
        return this.radius;
    }

    /**
     * Obtenir la couleur de la famille.
     * 
     * @return la couleur de la famille.
     */
    public Color getColor() {
        return this.color;
    }
    
    /**
     * Renvoie une copie de la famille.
     * 
     * @return copie de la famille
     */
    public Famille copy() {
      return new Famille(this.nom, this.color, this.mass, this.radius, 0);
    }

}
