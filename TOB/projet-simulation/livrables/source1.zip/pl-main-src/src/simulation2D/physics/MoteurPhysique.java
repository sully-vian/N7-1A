package simulation2D.physics;

import java.util.List;

import simulation2D.Launch;
import simulation2D.objects.Particule;

/**
 * La classe <code>PhysicsEngine</code> est responsable de la gestion de la
 * physique. Elle ne centralise pas tout et n'es sûrement pas dans son état
 * final.
 * TODO
 *
 * @author Vianney Hervy
 */
public class MoteurPhysique {

    /**
     * Le pas de temps en secondes.
     */
    private static final double DELTA_T = 1.0 / Launch.FPS;

    /**
     * Appliquer les forces aux objets. C'est à dire calculer leur nouveau vecteur
     * vitesse.
     *
     * @param objects la liste des objets
     */
    public static void applyForces(List<Particule> objects) {
        for (Particule object : objects) {
            applyForces(object);
        }
    }

    /**
     * Appliquer les forces à un objet.
     * @param object l'objet
     */
    public static void applyForces(Particule object) {
        Vecteur2D acceleration = object.getForce().divide(object.getMass());
        Vecteur2D addedVelocity = acceleration.times(DELTA_T);
        object.addVelocity(addedVelocity);
        object.resetForce();
    }

    /**
     * Mettre à jour les positions des objets.
     *
     * @param objects la liste des objets
     */
    public static void updatePositions(List<Particule> objects) {
        for (Particule object : objects) {
            updatePosition(object);
        }
    }

    public static void updatePosition(Particule object) {
        Vecteur2D displacement = object.getVelocity().times(DELTA_T);
        object.translate(displacement);
    }

}