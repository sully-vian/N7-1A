package simulation2D.physics;

import simulation2D.objects.Famille;

/**
 * La classe <code>Relation</code> defini la relation entre deux familles.
 *
 * @author Baptiste Gomez
 */
public class Relation {
  
  /**
   * Famille qui attire l'autre vers elle
   */
  private Famille attractrice;

  /**
   * Famille qui subit l'attraction de l'autre
   */
  private Famille subis;

  /**
   * Intensité de la relation
   */
  private double intensite;

  /**
   * 
   * @param attractrice Famille qui attire l'autre
   * @param subis Famille qui subit l'attraction
   * @param intensite Intensité de la relation
   */
  public Relation(Famille attractrice, Famille subis, double intensite) {
    this.attractrice = attractrice;
    this.subis = subis;
    this.intensite = intensite;
  }

  /**
   * Obtenir l'intensité de la relation
   * 
   * @return Intensité de la relation
   */
  public double getIntensite() {
    return this.intensite;
  }

  /**
   * Changer l'intensité de la relation
   * 
   * @param intensite Intensité de la relation
   */
  public void setIntensite(double intensite) {
    this.intensite = intensite;
  }

  /**
   * Obtenir la famille qui attire l'autre
   * 
   * @return La famille qui attire l'autre
   */
  public Famille getAttractrice() {
    return this.attractrice.copy();
  }

  /**
   * Obtenir la famille qui subit l'attraction
   * 
   * @return La  famille qui subit l'attraction
   */
  public Famille getSubis() {
    return this.subis.copy();
  }

  /**
   * Renvoie une copie de la relation
   * 
   * @return copie de la relation
   */
  public Relation copy() {
    return new Relation(getAttractrice(), getSubis(), getIntensite());
  }
}
