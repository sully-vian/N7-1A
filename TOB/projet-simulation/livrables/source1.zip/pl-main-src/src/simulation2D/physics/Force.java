package simulation2D.physics;

import java.util.List;

import simulation2D.objects.Dico2D;
import simulation2D.objects.Particule;

/**
 * La classe <code>ForceHandler</code> est responsable du calcul des forces.
 *
 * @author Vianney Hervy
 */
public class Force {

    /**
     * Le champ de gravité en m/s^<sup>2</sup>.
     */
    private static final Vecteur2D GRAVITY = new Vecteur2D(0, 9.81);

    // constructeur privé pour empêcher l'instanciation de la classe
    private Force() {
    }

    /**
     * Calculer les forces pour tous les objets.
     *
     * @param objects la liste des objets
     */
    public static void calculateForces(List<Particule> objects, Dico2D relations) {
        for (Particule object : objects) {
            for (Particule object2 : objects) {
              calculateForce(object, object2, relations);
            }
        }
    }

    /**
     * Calculer les forces pour un objet.
     *
     * @param object l'objet pour lequel on veut calculer les forces
     */
    private static void calculateForce(Particule object) {
        Vecteur2D gravitationalForce = GRAVITY.times(object.getMass());
        object.addForce(gravitationalForce);
    }

    private static void calculateForce(Particule object, Particule object2, Dico2D relations) {
      double dx = object2.getX() - object.getX();
      double dy = object2.getY() - object.getY();

      Vecteur2D force = new Vecteur2D(dx, dy);
      force.times(relations.getIntensite(object2.getFamille(), object.getFamille()));
      object.addForce(force);
    }

}
