package simulation2D.physics;

import java.util.List;

import simulation2D.Launch;
import simulation2D.objects.Particule;

/**
 * La classe <code>CollisionHandler</code> est responsable de la gestion des
 * collisions avec les murs et entre les objets.
 *
 * @author Vianney Hervy
 */
public class Collision {

    /**
     * Le facteur de rebondissement. C'est la proportion d'énergie conservée lors
     * d'une collision. Si BOUNCE = 1, la collision est parfaitement élastique.
     */
    private static final double BOUNCE = 1;

    // constructeur privé pour empêcher l'instanciation de la classe
    private Collision() {
    }

    /**
     * Vérifier les collisions avec les murs pour tous les objets.
     *
     * @param objects la liste des objets
     */
    public static void checkWallCollisions(List<Particule> objects) {
        for (Particule object : objects) {
            checkWallCollision(object);
        }
    }

    /**
     * Vérifier les collisions avec les murs pour un objet.
     *
     * @param object l'objet dont on veut vérifier la collision avec les murs
     */
    public static void checkWallCollision(Particule object) {

        if (object.getLeft() <= 0) {
            handleLeftWallCollision(object);
        }

        if (object.getRight() >= Launch.WIDTH) {
            handleRightWallCollision(object);
        }

        if (object.getTop() <= 0) {
            handleCeilingCollision(object);
        }

        if (object.getBottom() >= Launch.HEIGHT) {
            handleFloorCollision(object);
        }
    }

    /**
     * Gérer la collision avec le mur de gauche.
     *
     * @param object l'objet qui a collisionné avec le mur de gauche
     */
    public static void handleLeftWallCollision(Particule object) {
        object.setLeft(0);
        Vecteur2D velocity = object.getVelocity();
        object.setVelocity(velocity.getX() * -BOUNCE, velocity.getY());
    }

    /**
     * Gérer la collision avec le mur de droite.
     *
     * @param object l'objet qui a collisionné avec le mur de droite
     */
    public static void handleRightWallCollision(Particule object) {
        object.setRight(Launch.WIDTH);
        Vecteur2D velocity = object.getVelocity();
        object.setVelocity(velocity.getX() * -BOUNCE, velocity.getY());
    }

    /**
     * Gérer la collision avec le plafond (mur supérieur).
     *
     * @param object l'objet qui a collisionné avec le plafond
     */
    public static void handleCeilingCollision(Particule object) {
        object.setTop(0);
        Vecteur2D velocity = object.getVelocity();
        object.setVelocity(velocity.getX(), velocity.getY() * -BOUNCE);
    }

    /**
     * Gérer la collision avec le sol (mur inférieur).
     *
     * @param object l'objet qui a collisionné avec le sol
     */
    public static void handleFloorCollision(Particule object) {
        object.setBottom(Launch.HEIGHT);
        Vecteur2D velocity = object.getVelocity();
        object.setVelocity(velocity.getX(), velocity.getY() * -BOUNCE);
    }

    /**
     * Vérifier les collisions entre les objets.
     *
     * @param objects la liste des objets
     */
    public static void checkObjectCollisions(List<Particule> objects) {
        for (int i = 0; i < objects.size(); i++) {
            Particule objectA = objects.get(i);
            for (int j = i + 1; j < objects.size(); j++) {
                Particule objectB = objects.get(j);
                double distance = objectA.isOverlapping(objectB);

                if (distance != -1) { /* collision */
                    handleCollision(objectA, objectB, distance);
                }
            }
        }
    }

    /**
     * Gérer la collision entre deux objets.
     *
     * @param objectA  le premier objet
     * @param objectB  le deuxième objet
     * @param distance la distance entre les centres des deux objets
     */
    public static void handleCollision(Particule objectA, Particule objectB, double distance) {
        // Vecteur du centre de A au centre de B
        Vecteur2D normal = objectA.getPosition().minus(objectB.getPosition());
        normal.normalize();

        double overlap = objectA.getRadius() + objectB.getRadius() - distance;

        // Séparation des objets pour éviter la superposition à l'affichage
        objectA.translate(normal.times(overlap / 2));
        objectB.translate(normal.times(-overlap / 2));

        // vitesse relative
        Vecteur2D deltaV = objectA.getVelocity().minus(objectB.getVelocity());

        // vitesse relative selon la normale
        double normalVelocity = deltaV.dotProduct(normal);
        if (normalVelocity > 0) {
            // les objets se séparent déjà (ils sont passés l'un à travers l'autre)
            return;
        }

        // obtenir les masses des objets
        double mA = objectA.getMass();
        double mB = objectB.getMass();
        double mTot = mA + mB;

        // mettre à l'échelle la vitesse normale par la masse : plus la masse est
        // grande, moins la vitesse est affectée
        double scaledNormVelA = (2 * mB / mTot) * normalVelocity;
        double scaledNormVelB = (2 * mA / mTot) * normalVelocity;

        // calculer les nouvelles vitesses
        Vecteur2D vANew = objectA.getVelocity().minus(normal.times(scaledNormVelA));
        Vecteur2D vBNew = objectB.getVelocity().plus(normal.times(scaledNormVelB));

        // changer la vitesse des objets en appliquant le facteur de rebond
        objectA.setVelocity(vANew.times(BOUNCE));
        objectB.setVelocity(vBNew.times(BOUNCE));

    }

}
