% Fonction ecriture_RVB

function image_RVB = ecriture_RVB(image_originale)



end