
% Fonction calculs_basiques_variante --------------------------------------

function resultats = calculs_basiques_variante(A, B)

    resultats = [A+B, A-B, A*B];
    
end