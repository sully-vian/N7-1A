
% Fonction calculs_basiques -----------------------------------------------

function [somme, difference, produit] = calculs_basiques(A, B)

    somme = A+B;
    difference = A-B;
    produit = A.*B;
    
end